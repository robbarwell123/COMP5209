<?php
	return [
		'sDBServer'=>'localhost',
		'sDBUser'=>'email',
		'sDBPassword'=>'email',
		'sDBName'=>'email',
		'iOverlapMin'=>49
	];
?>