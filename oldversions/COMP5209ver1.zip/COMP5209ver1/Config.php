<?php
	return [
		'sDBServer'=>'localhost',
		'sDBUser'=>'email',
		'sDBPassword'=>'email',
		'sDBName'=>'emailver1'
	];
?>